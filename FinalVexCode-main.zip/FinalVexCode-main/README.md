# FinalVexCode
### This is so Sad. Can we Please get 5 Likes.
Thanks to Covid, 
this is where a kick-ass program
for a kick-ass world-champion class robotics team
goes to die.
