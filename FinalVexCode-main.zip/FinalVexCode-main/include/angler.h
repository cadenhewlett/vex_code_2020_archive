#ifndef _ANGLER_H_
#define _ANGLER_H_

#include "main.h"
void Angler_Task_fn(void * parameter);

#endif
