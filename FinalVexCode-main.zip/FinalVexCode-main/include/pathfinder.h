#ifndef PATHFINDER_H_
#define PATHFINDER_H_
#include "main.h"

#define PATH1 0
#define PATH2 1
#define NONE 3

class Pathfinder{
public:
  void followBackPath();
  void followPath(int PathID, bool backward, bool mirrored);
};
#endif
