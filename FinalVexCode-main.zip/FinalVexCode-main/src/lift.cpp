#include "main.h"
#include "lift.h"
#include "display.h"

void Lift_Task_fn(void * ignore){
  int err = 0;
  int err_last = 0;
  int i = 0;
  int armValue = 0;
  int armPower= 0;
  int derr = 0;
  int currentTarget;
  bool armToggled = false;
  bool slowTake = false;
  bool lightChanged = false;
  int count = 0;
  //This is split into two segments: Roller and Lift. Some functionalities of one are dependent
  //on the other, so they are both programmed in this file to make their interactions more dynamic.
  IntakeMotor.set_brake_mode(MOTOR_BRAKE_BRAKE);
  RollerMotor.set_brake_mode(MOTOR_BRAKE_BRAKE);

  while(true){
  //  lv_task_handler();

    /*******************************
    ************* LIFT *************
    ********************************/

    if(competition::is_autonomous()){
      currentTarget = armAutoTarget; //sets target to manually control.ed 'auto' target
      if(currentTarget == CUBE_LIFT_PRESET){ //if we're doing a cube lift thing
        currentTarget = presets[MIDDLE_PRESET]; //go to mid preset
        slowTake = true; //and activate the 'slowTake' procedure
      }
      else{
        slowTake = false; //otherwise don't slowTake
      }
    }

    else{ //'Scroll Wheel' Style of Preset Selection

      if(master.get_digital(E_CONTROLLER_DIGITAL_L1) && armToggled == false){ //if L1 change target value to 300
        i += 1; //increment our current preset state
        armToggled = true; //a button has been toggled
        slowTake = false; //we are not intaking briefly
      }

      else if(master.get_digital(E_CONTROLLER_DIGITAL_L2) && armToggled == false){ //if L2 then change target to 110
        i -= 1; //decrement our current preset state
        armToggled = true; //a button has been toggled
        slowTake = false; //we are not intaking briefly
      }

      if(master.get_digital(E_CONTROLLER_DIGITAL_X) && armToggled == false){ //if X then move to first index and move intake slightly
        i = 1; //move to middle state
        slowTake = true; //starts our small cube intake process (see below)
      }

      if(i > 2){i = 0;} //if the index of our presets is too high, return it to start
      else if(i < 0){i = 2;}//if the index is too low, return it to the top

      if(!master.get_digital(E_CONTROLLER_DIGITAL_L1) && !master.get_digital(E_CONTROLLER_DIGITAL_L2) && !master.get_digital(E_CONTROLLER_DIGITAL_X)){
        armToggled = false; //resets the toggled variable if none of the buttons are pressed. This helps prevent double clicking.
      }

      currentTarget = presets[i]; //target value is the index of the presets array in initialize.cpp
    }

    armValue = abs(LiftL.get_position()); //current value equals encoder reading

    err = currentTarget - armValue; //err equals target value minus current position
    err_last = err; //stores last err
    derr = err - err_last; //determines the change of err in one rotation

    armPower = (0.8 * err) + (1.2 * derr); //output equals sum of 'p' multiplied by its constant and 'd' multiplied by its constant
    armPower = (armPower > 127 ? 127 : armPower < -127 ? -127 : armPower); //caps speed at +- 127

    LiftL.move(-armPower); //NOTE: NEEDS TEST

    /*******************************
    ********** ROLLERS *************
    ********************************/

    if((competition::is_autonomous())){ //if we're not in auto

    if(LineTracking){ //if global 'line tacking' variable is true
      if(LightSensor.get_value() > 1000){//if there is no cube over the sensor was > 2800
         rollerSpeed = -70; //move the rollers until a cube covers the sensor
         if(lightChanged){
           rollerSpeed = 0; //stop when a cube is over the sensor
           lightChanged = false;
         }
      }
      else{
        if(LightSensor.get_value() < 1000){
          lightChanged = true;
        }
        if(lightChanged){
          if(count < 75){
            rollerSpeed = -70; //move the rollers until a cube covers the sensor
            count++;
          }
          else{
            rollerSpeed = 0; //stop when a cube is over the sensor
          }
        }
      }
    }
/*  if(LightSensor.get_value() < 2800){//if there is no cube over the sensor was > 2800
     lightChanged = true;
  }
  if(lightChanged){
    count += 1;
  }
  if(count < 75){
    rollerSpeed = -67;
  }
  else{
    rollerSpeed = 0;
    count = 0;
    lightChanged = false;
  }
*/
    else if(slowTake){ //if global 'slow taking' variable is true
          if(armValue < 70){
            rollerSpeed = 67; //while armValue is less than 200 set speed to 67
          }
          else{//once value is greater than 200
            rollerSpeed = 0; //set speed to 0
          }
        }
        else{ //if neither of the previous states are true
          rollerSpeed = rollerSpeed; //set speed to whatever I've manually set it to be in autonomous.cpp
        }
      }
    else { //if it is opcontrol

      if(master.get_digital(E_CONTROLLER_DIGITAL_R1)){ //if R1 is pressed
        rollerSpeed = -127; //set speed to -127
      }
      else if(master.get_digital(E_CONTROLLER_DIGITAL_R2)){ //otherwise if R2 is pressed
        rollerSpeed = 127;  //set speed to 127
      }
      else if(slowTake){ //if we're slowtaking

        if(armValue < 70){ //while armValue is less than 200
          rollerSpeed = 67; //set speed to 67
          }
          else{ //once value is greater than 200
            rollerSpeed = 0; //stop moving the rollers
          }

        }
        else{ //if no buttons are pressed
          rollerSpeed = 0; //set speed to 0
        }

    }

    //If we're not slowtaking and we're not on a middle or top preset
    if(!(slowTake) && (currentTarget == presets[MIDDLE_PRESET] || currentTarget == presets[TOP_PRESET])){
      rollerSpeed = rollerSpeed  * 0.60; //Decrease roller speed so we don't overshoot
    }

    IntakeMotor.move(-rollerSpeed); //move roller motors according to rollerSpeed
    RollerMotor.move(-rollerSpeed); //move roller motors according to rollerSpeed
    delay(10);
  }
}
