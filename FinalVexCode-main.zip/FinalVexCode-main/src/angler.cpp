#include "main.h"
#include "angler.h"
#include "display.h"

void Angler_Task_fn(void * ignore){

  //declare variables
  int err = 0;
  int err_last = 0;
  int currentValue;
  int targetValue = 2480;
  bool buttonStop = false;
  int motorPower;
  int cap;
  int derr;

  while(true){ //continuous task

    currentValue = abs(TrayPot.get_value_calibrated()); //gets the potentiometer value

    if(competition::is_autonomous()){ //if we're in auto

      targetValue = anglerAutoTarget; //autonomous control is a variable changed in autonomous.cpp

    }
    else{ //otherwise if we're in opcontrol

      if(master.get_digital(E_CONTROLLER_DIGITAL_DOWN)){ //if down button
        targetValue = 2480; //sets the target to be Bottom Position (WAS 0)
      }
      else if(master.get_digital(E_CONTROLLER_DIGITAL_UP)){ //if up button
        targetValue = 975; //90 degree position (WAS 870)
      }
      else if(master.get_digital(E_CONTROLLER_DIGITAL_LEFT)){ //if left button
        targetValue = 100; //score top tower position
      }

    }

    if((targetValue == 975) && currentValue < 1650){ //if we're going to highest preset and we're past appx. halfway
      cap = 50; //slow down so we don't knock down the tower
    }
    else{
      cap = 127; //otherwise move normally
    }

    err = targetValue - currentValue; //error is delta of target and current positions
    err_last = err; //store last error
    derr = err - err_last; //difference of errors over iterations
    motorPower = (0.35 * err) + (0.8 * derr); //PD constants plus our variables
  //  motorPower = motorPower > cap ?  cap : motorPower < -127 ? -127 : motorPower; //caps output at +cap, -127
    motorPower = motorPower > 127 ?  127 : motorPower < -cap ? -cap : motorPower; //caps output at +cap, -127

    if((targetValue == 2480)&&(abs(err) < 10)){  //if we're near the bottom
      TrayMotor.move(0); //stop movement, to prevent the motor from overheating
    }
    else{
      TrayMotor.move(motorPower); //move the lift equal to motorPower, meaning standard PD movement
    }
    delay(10); //loop delay
  }

}
