#include "main.h"

#include <string.h>


	Controller master(E_CONTROLLER_MASTER); //Main Controller
	Controller partner(E_CONTROLLER_PARTNER); //Partner Controller

	//Sensors
	ADIGyro gyro('i'); //Gyroscope

	Vision visionSensor(1); //Initialize Vision Sensor
	ADIDigitalIn button('c'); //A button that acts as a hard stop for the Angler
	//ADIDigitalIn armbutton('c');
	ADIAnalogIn accelerometer('a');
	ADIAnalogIn LightSensor('d'); //Not plugged in right now
	ADIAnalogIn TrayPot('b'); //Potentiometer on the angler
	ADIUltrasonic leftUlt('G', 'H'); //orange(ping), yellow(echo)
	ADIUltrasonic rightUlt('E','F'); //orange(ping), yellow(echo)

	//Motors

	//#NOTE Broken Ports: 9, 7, 2

	Motor BaseFL(14, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //Front Left Base Motor WAS 3
	Motor BaseFR(13, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //Back Left Base Motor WAS 9
	Motor BaseBL(19, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //Front Right Base Motor WAS 1
	Motor BaseBR(20, E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //Back Right Base Motor WAS 10
	Motor EmptyMotor(45,  E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //An Empty Motor, used as the default Test Motor
	Motor LiftL(18, E_MOTOR_GEARSET_36, true, E_MOTOR_ENCODER_DEGREES); //The Arm Motor WAS 5
	Motor TrayMotor(17, E_MOTOR_GEARSET_36, true, E_MOTOR_ENCODER_DEGREES); //the Tray Motor WAS 6
	Motor IntakeMotor(15, E_MOTOR_GEARSET_36, false, E_MOTOR_ENCODER_DEGREES); //The left roller motor WAS 7
  Motor RollerMotor(16, E_MOTOR_GEARSET_36, true, E_MOTOR_ENCODER_DEGREES); //The right roller motor WAS 4
	Motor LiftR(72,  E_MOTOR_GEARSET_18, true, E_MOTOR_ENCODER_DEGREES); //Another Empty motor. Will be added in the program again if we ever switch back to a 2 motor lift

	//Motor Groups
	Motor ChassisMotors[4] = {BaseFL, BaseFR, BaseBL, BaseBR}; //Array of All Motors in the Chassis

	//Variables
	int armAutoTarget = presets[BOTTOM_PRESET];
	int anglerAutoTarget = 2480;
	bool LineTracking = false;
	int currentAuto = NO_AUTO_SELECTED; //Current Auto (From the Auto Selector)
	int currentTestMotor = 0; //Current Motor Being Tested (From the Drop Down Menu)
	int presets[3] = {0, 375, 500}; //Array of presets for the Arm, which is used in lift.cpp: WAS {0, 500, 630}
	int currentLiftPreset = 0; //A variable to store our current active preset (from above)
	int rollerSpeed = 0; //Roller Intake Global Speed

	//Classes
 	Display screen; //The Screen on the V5 Brain (from display.cpp)
	Chassis base; //The Base/Chassis of the Robot (from chassis.cpp)
	Camera camera; //A Vision Sensor object (from vision.cpp)
	Pathfinder profile; //Our 2D Motion Profiling Object


void initialize() {

	BaseFL.set_brake_mode(MOTOR_BRAKE_BRAKE);
	BaseFR.set_brake_mode(MOTOR_BRAKE_BRAKE);
	BaseBL.set_brake_mode(MOTOR_BRAKE_BRAKE);
	BaseBR.set_brake_mode(MOTOR_BRAKE_BRAKE);
	accelerometer.calibrate();
	//Declare Our Tasks
	 Task Angler_Task (Angler_Task_fn, (void*)"PROS", TASK_PRIORITY_DEFAULT,
	 			TASK_STACK_DEPTH_DEFAULT,	"Angler Task");

	 Task Lift_Task (Lift_Task_fn, (void*)"PROS", TASK_PRIORITY_DEFAULT,
 				TASK_STACK_DEPTH_DEFAULT, "Lift Task");


	 //Create the Screen
	 screen.createScreen(); //Creates the Items on the Screen. This is only called once.

	 delay(100);
}


void disabled() {
	screen.refresh();
	BaseFL.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseFR.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseBL.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseBR.set_brake_mode(MOTOR_BRAKE_COAST);
}

void competition_initialize() {}

void autonomous() {

	BaseFL.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseFR.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseBL.set_brake_mode(MOTOR_BRAKE_COAST);
	BaseBR.set_brake_mode(MOTOR_BRAKE_COAST);
	//profile.followPath(PATH1);
  anglerAutoTarget = 2480;
//	TrayPot.calibrate();
	//	rollerSpeed = -127;
	armAutoTarget = presets[TOP_PRESET];
	delay(500);
//  intake.autoIntake(127);
	armAutoTarget = presets[0];
	delay(750);
//950 + 505 = 1455
if(currentAuto == AUTO_UNPROTEC_BLUE){
	rollerSpeed = -127;
	base.MoveDistance(DIRECTION_FORWARD,  1150, 1250, 90);//was950 and 1150

	base.stopDriving();
	//delay(50);
	base.MoveDistance(DIRECTION_FORWARD, 400, 550, 45); //was535 and 1000

	//delay(150);
	profile.followPath(PATH1, true, true);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1800, 2250, 70);
	base.stopDriving();
	delay(50);
	rollerSpeed = -127;
//	profile.followBackPath();
//	base.TurnDistance(DIRECTION_RIGHT, 615, 1000);
//	base.stopDriving();
/*
	base.StrafeDistance(DIRECTION_LEFT, 1150, 1250);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1600, 1650, 85);
*/

	rollerSpeed = 45;
	delay(125);
	rollerSpeed = 0;

	anglerAutoTarget = 1750;
	base.fence(0.4, 1.0, 135, 1000);
	delay(50);
	base.stopDriving();

//	delay(350);


	base.TurnDistance(DIRECTION_LEFT, 1300, 1100);
	base.stopDriving();
//	delay(100);
	base.MoveDistance(DIRECTION_FORWARD, 3000, 900, 100);//YEET
	rollerSpeed = 0;
	base.buttonStop(650);
//	LineTracking = false;
	base.stopDriving();
	//delay(100);
//	rollerSpeed = 0;
	base.StrafeDistance(DIRECTION_LEFT, 600, 200);

  anglerAutoTarget = 975;
  delay(2450);
  //base.buttonStop(750);
  base.MoveDistance(DIRECTION_BACKWARD, 9000, 750, 127);

  base.stopDriving();
  delay(200);
  anglerAutoTarget = 2480;
}
else if(currentAuto == AUTO_UNPROTEC_RED){
	rollerSpeed = -127;
	base.MoveDistance(DIRECTION_FORWARD,  1150, 1250, 90);//was950 and 1150

	base.stopDriving();
	//delay(50);
	base.MoveDistance(DIRECTION_FORWARD, 400, 550, 45); //was535 and 1000

	//delay(150);
	profile.followPath(PATH1, true, false);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1800, 2250, 70);
	base.stopDriving();
	delay(50);
	rollerSpeed = -127;
//	profile.followBackPath();
//	base.TurnDistance(DIRECTION_RIGHT, 615, 1000);
//	base.stopDriving();
/*
	base.StrafeDistance(DIRECTION_LEFT, 1150, 1250);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1600, 1650, 85);
*/

	rollerSpeed = 45;
	delay(125);
	rollerSpeed = 0;

	anglerAutoTarget = 1750;
	base.fence(0.4, 1.0, 135, 1000);
	delay(50);
	base.stopDriving();

//	delay(350);

	base.TurnDistance(DIRECTION_RIGHT, 1300, 1100);
	base.stopDriving();
//	delay(100);
	base.MoveDistance(DIRECTION_FORWARD, 3000, 900, 100);//YEET
	rollerSpeed = 0;
	base.buttonStop(650);
//	LineTracking = false;
	base.stopDriving();
	//delay(100);
//	rollerSpeed = 0;
	base.StrafeDistance(DIRECTION_RIGHT, 600, 375);

	anglerAutoTarget = 975;
	delay(2600);
	//base.buttonStop(750);
	base.MoveDistance(DIRECTION_BACKWARD, 1200, 750, 127);

	base.stopDriving();
	delay(200);
	anglerAutoTarget = 2480;
}
else if(currentAuto == AUTO_SKILLS){
	rollerSpeed = -127;
	base.MoveDistance(DIRECTION_FORWARD,  1150, 1250, 90);//was950 and 1150

	base.stopDriving();
	//delay(50);
	base.MoveDistance(DIRECTION_FORWARD, 500, 800, 45); //was535 and 1000

	//delay(150);
	profile.followPath(PATH1, true, false);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1800, 2250, 70);
	base.stopDriving();
	delay(50);
	rollerSpeed = -127;
//	profile.followBackPath();
//	base.TurnDistance(DIRECTION_RIGHT, 615, 1000);
//	base.stopDriving();
/*
	base.StrafeDistance(DIRECTION_LEFT, 1150, 1250);
	delay(50);
	base.stopDriving();
	base.MoveDistance(DIRECTION_FORWARD, 1600, 1650, 85);
*/

	rollerSpeed = 45;
	delay(125);
	rollerSpeed = 0;

	anglerAutoTarget = 1750;
	base.fence(0.4, 1.0, 135, 1000);
	delay(50);
	base.stopDriving();

//	delay(350);

	base.TurnDistance(DIRECTION_RIGHT, 1300, 1000);
	base.stopDriving();
//	delay(100);
	base.MoveDistance(DIRECTION_FORWARD, 3000, 850, 100);//YEET
	rollerSpeed = 0;
	base.buttonStop(650);
//	LineTracking = false;
	base.stopDriving();
	//delay(100);
//	rollerSpeed = 0;
	base.StrafeDistance(DIRECTION_RIGHT, 600, 375);

	anglerAutoTarget = 975;
	delay(5200);
	//base.buttonStop(750);
	base.MoveDistance(DIRECTION_BACKWARD, 450, 750, 90);

	base.stopDriving();
	delay(200);
	anglerAutoTarget = 2480;
	}
}

void opcontrol() {

	int timer = 0;
	screen.setActiveTab(TAB_DISPLAY);
	//profile.followPath();

	while (true) {

		if(!alternating){timer++;}

		if(timer == 2000){
			screen.setActiveTab(TAB_INFO);
		}
		if(timer == 3000){
			screen.setActiveTab(TAB_DISPLAY);
		}
		if(timer == 4000){
			screen.setActiveTab(TAB_DIAGNOSTIC);
			timer = 0;
		}
		//	screen.setActiveTab(TAB_INFO);
		//	lv_task_handler();
		//	camera.getNearestSig(); //Get sthe vision sensor to fetch and process values.
			base.OP_Chassis(); //Robot chassis OpControl Routine
			screen.refresh(); //Refresh the screen values
			delay(5);


	}
}
