#include "main.h"
#include "vision.h"
#include <string.h>

int Camera::getObjectXVal(int objectSig){
  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  return object.x_middle_coord;
}

int Camera::getNearestSig(void){
  vision_object_s_t biggestObject = visionSensor.get_by_size(0);
  return biggestObject.signature;
}

int Camera::getObjectYVal(int objectSig){

  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  return object.y_middle_coord;
}

int Camera::getObjectWidth(int objectSig){
  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  return object.width;
}

int Camera::getObjectHeight(int objectSig){
  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  return object.height;
}


//X == 86
void Camera::centerToObject(int objectSig, int targetValue, int timeout){

  float driveKP = 0.7; //constants //was 0.2
  float driveKD = 1.3; //was 0.4
  float driveKI = 0.00005; //was 0.009
    //same PID Logic as turnValue in chassis.cpp
  int motorPower;
  int startTime = millis();
  int currentValue = 0;
  int err = 0;
  int derr = 0;
  int err_last = 0;
  int err_sum = 0;

  float p;
  float i = 0;
  double direction = 1;
  float d;

  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  screen.setActiveTab(TAB_INFO);

  while((millis() - startTime) < timeout){

    screen.refresh();
    object = visionSensor.get_by_sig(0, objectSig);

    currentValue = object.x_middle_coord;

    err = targetValue - currentValue;  //err equals target minus current value
    err_last = err; //store last error
    p = (driveKP * err);

    err_sum += err; //increment error sum
    i = driveKI * err_sum;

    derr = (err - err_last); //error difference is the delta of the errors
    d = driveKD * derr;

    motorPower = p+i+d; //output equals sum of  KP x I_err and KD x dI_err: PD Loop

    motorPower = (motorPower > 67 ? 67 : motorPower < -67 ? -67 : motorPower); //cap speed at +- 90


    if(abs(err) > 250){ ///if error greater than +- 200
      direction = 0; //THERE'S A PROBLEM OH GOD MAKE IT STOP
    }
    else{ //otherwise
      direction = 1; //it's all good. We're alive. For now...
    }

    BaseFL.move(-motorPower * direction);
    BaseBL.move(motorPower * direction);
    BaseFR.move(-motorPower * direction);
    BaseBR.move(motorPower * direction);
  }

}

void Camera::driveToObject(int objectSig, int targetValue, int timeout){

  float driveKP = 0.7; //constants //was 0.2
  float driveKD = 1.3; //was 0.4
  float driveKI = 0.000; //was 0.009

    //same PID Logic as turnValue in chassis.cpp
  int motorPower;
  int startTime = millis();
  int currentValue = 0;
  int err = 0;
  int derr = 0;
  int err_last = 0;
  int err_sum = 0;

  float p;
  float i = 0;
  double direction = 1;
  float d;
  vision_object_s_t object = visionSensor.get_by_sig(0, objectSig);
  screen.setActiveTab(TAB_INFO);

  while((millis() - startTime) < timeout){

    screen.refresh();
    object = visionSensor.get_by_sig(0, objectSig);

    currentValue = object.y_middle_coord;

    err = targetValue - currentValue;  //err equals target minus current value
    err_last = err; //store last error
    p = (driveKP * err);

    err_sum += err; //increment error sum
    i = driveKI * err_sum;

    derr = (err - err_last); //error difference is the delta of the errors
    d = driveKD * derr;

    motorPower = p+i+d; //output equals sum of  KP x I_err and KD x dI_err: PD Loop

    motorPower = (motorPower > 67 ? 67 : motorPower < -67 ? -67 : motorPower); //cap speed at +- 90


    if(abs(err) > 250){ ///if error greater than +- 200
      direction = 0; //THERE'S A PROBLEM OH GOD MAKE IT STOP
    }
    else{ //otherwise
      direction = 1; //it's all good. We're alive. For now...
    }

    BaseFL.move(motorPower * direction);
    BaseBL.move(motorPower * direction);
    BaseFR.move(-motorPower * direction);
    BaseBR.move(-motorPower * direction);
  }

}
void Camera::moveToObject(int objectSig, int timeout){
  centerToObject(objectSig, 140, timeout/2);
  delay(300);
  driveToObject(objectSig, -90  /*TESTVAL*/, timeout/2);
  base.stopDriving();
}
