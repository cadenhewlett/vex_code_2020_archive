#include "main.h"
#include "pathfinder.h"


void Pathfinder::followPath(int PathID, bool backward, bool mirrored){
  using namespace okapi;
  //Creates a Chassis Controller object that defines our base Dimensions and Motor Ports for later processing.
  std::shared_ptr<ChassisController> myChassis =
  ChassisControllerBuilder()
    .withMotors({-14, -19}, {13, 20})
    // Green gearset, 4 in wheel diam, 11.5 in wheel track
    .withDimensions(AbstractMotor::gearset::green, {{4_in, 11.5_in}, imev5GreenTPR})
    .build();

//max velwas 1, 4, 10
//Creates a Profile Controller from our Chassis Controller with a Max Velocity of 1, Max Acceleration of
  std::shared_ptr<AsyncMotionProfileController> profileController =
    AsyncMotionProfileControllerBuilder()
      .withLimits({1, 2, 10})
      .withOutput(myChassis)
      .buildMotionProfileController();
  profileController->generatePath({
    {0_ft, 0_ft, 0_deg},
    {10_in, 6_in, 60_deg},
    {20_in, 6_in, 60_deg},
    {28_in, 8_in, 0_deg}
  }, "First");

  profileController->generatePath({
    {0_ft, 0_ft, 0_deg},
    {20_in, 47_in, 0_deg}
  }, "BetterPath");


  profileController->setTarget("BetterPath", backward, mirrored);
      profileController->waitUntilSettled();

}
void Pathfinder::followBackPath(void){
  using namespace okapi;
  //Creates a Chassis Controller object that defines our base Dimensions and Motor Ports for later processing.
  std::shared_ptr<ChassisController> myChassis =
  ChassisControllerBuilder()
    .withMotors({-14, -19}, {13, 20})
    // Green gearset, 4 in wheel diam, 11.5 in wheel track
    .withDimensions(AbstractMotor::gearset::green, {{4_in, 11.5_in}, imev5GreenTPR})
    .build();

//max velwas 1, 4, 10
//Creates a Profile Controller from our Chassis Controller with a Max Velocity of 1, Max Acceleration of
  std::shared_ptr<AsyncMotionProfileController> profileController =
    AsyncMotionProfileControllerBuilder()
      .withLimits({1, 2, 10})
      .withOutput(myChassis)
      .buildMotionProfileController();
  profileController->generatePath({
    {0_ft, 0_ft, 0_deg},
    {10_in, 6_in, 60_deg},
    {20_in, 6_in, 60_deg},
    {28_in, 8_in, 0_deg}
  }, "First");

  profileController->generatePath({
    {0_ft, 0_ft, 0_deg},
    {20_in, 47_in, 0_deg}
  }, "BetterPath");


  profileController->setTarget("BetterPath", true, false);
      profileController->waitUntilSettled();
}
