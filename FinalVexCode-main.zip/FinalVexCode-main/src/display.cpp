#include "main.h"
#include "display.h"
#include "vision.h"
#include "lift.h"
#include <string.h>

extern const _lv_img_t logo;

extern lv_obj_t*tabs;
extern lv_obj_t*auto_op_tab;
extern lv_obj_t*disabled_tab;
extern lv_obj_t*test_tab;
extern lv_obj_t*motor_test_tab;
extern lv_obj_t*diagnostic_tab;
extern lv_obj_t*gyroGauge;
extern lv_obj_t*frontLED;

//Switch Globals
bool alternating = false;
bool on;

/*
*** CREATE FUNCTIONS FOR SPECIFIC OBJECTS ***
Since these 'actions' are assigned outside of the regular program,
it means that these actions can occur even when the primary execution
loop isn't running. This means we can select autos and stuff while the
robot is disabled.
*/
lv_res_t dropDown_action(lv_obj_t * list){

  currentTestMotor = lv_ddlist_get_selected(list); //Changes Global Variable of Test motor to the Index of the List.

  return LV_RES_OK; //return OK for complete execution
}

lv_res_t autoSelect_action(lv_obj_t * selector){
  currentAuto = lv_roller_get_selected(selector); /*Changes the current auto to be the list option index*/

  return LV_RES_OK; //return OK for complete execution
}

lv_res_t fb_switch_action(lv_obj_t*swtch){
  if(lv_sw_get_state(swtch) == SWITCH_FORWARD){
    alternating = true;
  }
  else{
    alternating = false;
  }
  return LV_RES_OK; //return OK for complete execution
}

lv_res_t oo_switch_action(lv_obj_t*swtch){
  if(lv_sw_get_state(swtch) == SWITCH_FORWARD){
    on = true;
  }
  else{
    on = false;
  }
  return LV_RES_OK;
}

lv_obj_t * tabs = lv_tabview_create(lv_scr_act(), NULL); //Declare tabview on default tab
lv_obj_t * auto_op_tab = lv_tabview_add_tab(tabs, "Enabled"); //Declare a tab
lv_obj_t * disabled_tab = lv_tabview_add_tab(tabs, "Disabled"); //Declare a tab
lv_obj_t * diagnostic_tab = lv_tabview_add_tab(tabs, "Diagnostic"); //Declare a tab

//lv_obj_t * motor_test_tab = lv_tabview_add_tab(tabs,"Test");

//Declare all of our objects
lv_theme_t *th;
lv_obj_t * autoSelector;
lv_obj_t * frontLED; //Declare an LED for the Front Light Sensor
lv_obj_t * backLED; //Declare an LED for the Back Light Sensor
lv_obj_t * lftLED; //Declare an LED for the Flywheel Target Velocirt
lv_obj_t * fnlLED;
lv_obj_t * motorBar1;
lv_obj_t * motorLabel1;
lv_obj_t * motorBar2;
lv_obj_t * motorLabel2;
lv_obj_t * motorBar3;
lv_obj_t * motorLabel3;
lv_obj_t * sys_battery_meter;
lv_obj_t * bat_meter_label;
lv_obj_t * symbol_label;
lv_obj_t * gyroGauge; //Declare a gauge for the gyro position
lv_obj_t * OnOffSwitch; //Declare our on/off switch for motor testing
lv_obj_t * directionSwitch; //Delcare our Forward/Backward switch for motor testing
lv_obj_t * motorSelect; //Declares our dropdown list for selecting which motor to test
lv_obj_t * gyroLabel;
lv_obj_t * visionObjectLabel;
lv_obj_t * batteryBar;
lv_obj_t * lightSensorLabel;
lv_obj_t * rightUltLabel;
lv_obj_t * leftUltLabel;
lv_obj_t* batTemperatureBar;
lv_obj_t * batTemperatureLabel;
lv_obj_t * visionXBar;
lv_obj_t * visionYBar;
lv_obj_t * visionXLabel;
lv_obj_t * visionYLabel;
lv_obj_t * dbLED;
lv_obj_t * opLED;
lv_obj_t * auLED;
lv_obj_t * dbLEDLabel;
lv_obj_t * opLEDLabel;
lv_obj_t * auLEDLabel;
lv_obj_t * accelBar;
lv_obj_t * accelLabel;
lv_obj_t * accelTitle;
_lv_img_t * img3;

void Display::create1010Image(void)
{

  LV_IMG_DECLARE(rszLogo_F);//declare from our C file
  lv_obj_t * img2 = lv_img_create(auto_op_tab, NULL); //create the new image
  lv_img_set_src(img2, &rszLogo_F);//sets the source of the image to be the array from the C File
  lv_obj_align(img2, NULL, LV_ALIGN_IN_TOP_LEFT, -25, 0); //align the image
  lv_img_set_auto_size(img2, true);
  lv_obj_set_size(img2, 360, 150);

  //lv_obj_set_size(img3, 100, 50);

}

void Display::createOpLEDs(void)
{
    frontLED = lv_led_create(auto_op_tab, NULL); //Declare an LED
  	backLED = lv_led_create(auto_op_tab, NULL); //Declare an LED
  	lftLED = lv_led_create(auto_op_tab, NULL); //Declare an LED
  	fnlLED = lv_led_create(auto_op_tab, NULL); //Declare an LED

  	lv_obj_align(frontLED, NULL, LV_ALIGN_IN_TOP_RIGHT, -20, 40); //Align our topmost LED to the top right of the screen
  	lv_obj_align(backLED, frontLED, LV_ALIGN_CENTER, 0, 45); //Align our middle LED to the topmost LED and adjust the Y Value
  	lv_obj_align(lftLED, backLED, LV_ALIGN_CENTER, 0, 45); //Align the bottomost LED to the middle LED and adjust the Y Value for equal displacement
  	lv_obj_align(fnlLED, lftLED, LV_ALIGN_CENTER, 0, 45);

    //Set LED Sizes
  	lv_obj_set_size(frontLED, 50, 35);
  	lv_obj_set_size(backLED, 50, 35);
  	lv_obj_set_size(lftLED, 50, 35);
  	lv_obj_set_size(fnlLED, 50, 35);

    //Create Labels for each LED
  	lv_obj_t * frontLabel = lv_label_create(auto_op_tab, NULL); //Create a Label for the Front Light Sensor LED
  	lv_obj_t * backLabel = lv_label_create(auto_op_tab, NULL); //Create a Label for the Back Light Sensor LED
  	lv_obj_t * fwLabel = lv_label_create(auto_op_tab, NULL); //Create a Label for the Flywheel Target Velocity LED
  	lv_obj_t * fnlLabel = lv_label_create(auto_op_tab, NULL);
    //Align each Label to their LED
  	lv_obj_align(frontLabel, frontLED, LV_ALIGN_CENTER, 0, 0); //Align our frontLabel to the frontLED with an X adjustment of 60 units
  	lv_obj_align(backLabel, backLED, LV_ALIGN_CENTER, 0, 0); //Align our backLabel to the backLED with an X adjustment of 60 units
  	lv_obj_align(fwLabel, lftLED, LV_ALIGN_CENTER, 0, 0); //Align our fwLabel to the fwLED with an X adjustment of 60 units
  	lv_obj_align(fnlLabel, fnlLED, LV_ALIGN_CENTER, 0, 0);

    //Set Label Text
  	lv_label_set_text(backLabel, "TRAY");
  	lv_label_set_text(fwLabel, "LIFT");
  	lv_label_set_text(frontLabel, "BUTN");
  	lv_label_set_text(fnlLabel, "LINE");

    //Also, create a bar to measure battery level
    batteryBar = lv_bar_create(auto_op_tab, NULL);
    lv_bar_set_range(batteryBar, 0, 100); //sets the range of the battery bar to be 0-100%

    lv_obj_set_size(batteryBar, 35, 160); //sets the size such that it is a vertical bar
    lv_obj_align(batteryBar, frontLED, LV_ALIGN_CENTER, -65, 70); //align to be beside our LEDs

}

void Display::createTitle(void){

  leftUltLabel = lv_label_create(disabled_tab, NULL);  //creates a label
  lv_obj_align(leftUltLabel, NULL, LV_ALIGN_IN_TOP_LEFT, 10, 0); //aligns it to the first label with Y adjustment
  lv_label_set_text(leftUltLabel, "Left Ult: N/A?");  //sets default text

  lightSensorLabel = lv_label_create(disabled_tab, NULL);  //creates a label
  lv_obj_align(lightSensorLabel, leftUltLabel, LV_ALIGN_IN_TOP_LEFT, 0, 25); //aligns it to the first label with Y adjustment
  lv_label_set_text(lightSensorLabel, "Line Sens: N/A?");  //sets default text

  rightUltLabel = lv_label_create(disabled_tab, NULL);  //creates a label
  lv_obj_align(rightUltLabel, leftUltLabel, LV_ALIGN_IN_TOP_LEFT, 0, -25); //aligns it to the first label with Y adjustment
  lv_label_set_text(rightUltLabel, "Right Ult: N/A?");  //sets default text
}

void Display::createGauge(){ //Create a Gauge for our Gyro Values and Bars for the Motor Values

//  lv_obj_set_parent(gyroGauge, lightSensorLabel);

  motorBar1 = lv_bar_create(disabled_tab, NULL); //creates a bar on the disabled mode tab
  motorLabel1 = lv_label_create(motorBar1, NULL); //creates a label for this bar
  lv_label_set_recolor(motorLabel1, true); //verifies that we can change the colour of label text

  lv_obj_set_size(motorBar1, 30, 155); //sets the size such that this is a vertical bar
  lv_obj_align(motorBar1, bat_meter_label, LV_ALIGN_CENTER, -190, 10); //aligns the bar to the top left of our gauge with major adjustments
  lv_bar_set_range(motorBar1, 1000, 2500); //sets the range of the bar to 0-1000

  lv_obj_set_size(motorLabel1, 30, 70); //sets the size of the label
  lv_obj_align(motorLabel1, motorBar1, LV_ALIGN_CENTER, 11, 0); //aligns the label to the center of the bar

  //lv_label_set_text(motorLabel1, "#0a0000 M1\n 100#");

  motorBar2 = lv_bar_create(disabled_tab, NULL); //creates a bar on the disabled mode tab
  motorLabel2 = lv_label_create(motorBar2, NULL); //creates a label for this bar
  lv_label_set_recolor(motorLabel2, true); //verifies that we can change the colour of label text

  lv_obj_set_size(motorBar2, 30, 155); //sets the size such that this is a vertical bar
  lv_obj_align(motorBar2, motorBar1, LV_ALIGN_IN_TOP_LEFT, 40, 0); //aligns the second bar to the first with X Adjustment proportional to the size
  lv_bar_set_range(motorBar2, 0, 680); //sets range to be 0 to 680

  lv_obj_set_size(motorLabel2, 30, 70); ///sets label size
  lv_obj_align(motorLabel2, motorBar2, LV_ALIGN_CENTER, 5, 0); //aligns the label to (roughly) the center of the bar

  motorBar3 = lv_bar_create(disabled_tab, NULL);
  motorLabel3 = lv_label_create(motorBar3, NULL);

  lv_obj_set_size(motorBar3, 30, 155); //sets the size such that this is a vertical bar
  lv_obj_align(motorBar3, motorBar2, LV_ALIGN_IN_TOP_LEFT, 40, 0); //aligns the second bar to the first with X Adjustment proportional to the size
  lv_bar_set_range(motorBar3, -127, 127); //sets range to be 0 to 680

  lv_obj_set_size(motorLabel3, 30, 70); ///sets label size
  lv_obj_align(motorLabel3, motorBar3, LV_ALIGN_CENTER, 11, 0); //aligns the label to (roughly) the center of the bar


}

void Display::createStateLEDs(){

  dbLED = lv_led_create(diagnostic_tab, NULL); //Declare an LED
  opLED = lv_led_create(diagnostic_tab, NULL); //Declare an LED
  auLED = lv_led_create(diagnostic_tab, NULL); //Declare an LED

  lv_obj_align(dbLED, gyroGauge, LV_ALIGN_CENTER, -50, 60); //Align our leftmost LED to be below the Gauge
  lv_obj_align(opLED, dbLED, LV_ALIGN_CENTER, 60, 0); //Align our middle LED to the leftMost LED and adjust the X Value
  lv_obj_align(auLED, opLED, LV_ALIGN_CENTER, 60, 0); //Align the rightMost LED to the middle LED and adjust the X Value for equal displacement

  //Set LED Sizes
  lv_obj_set_size(dbLED, 35, 35);
  lv_obj_set_size(opLED, 35, 35);
  lv_obj_set_size(auLED, 35, 35);

  //Set Default LED state
  lv_led_off(dbLED);
  lv_led_off(auLED);
  lv_led_off(opLED);

  //Create Labels for each LED
  lv_obj_t * dbLEDLabel = lv_label_create(diagnostic_tab, NULL); //Create a Label for the Front Light Sensor LED
  lv_obj_t * auLEDLabel = lv_label_create(diagnostic_tab, NULL); //Create a Label for the Back Light Sensor LED
  lv_obj_t * opLEDLabel = lv_label_create(diagnostic_tab, NULL); //Create a Label for the Flywheel Target Velocity LED

  //Align each Label to their LED
  lv_obj_align(dbLEDLabel, dbLED, LV_ALIGN_CENTER, 10, 0); //Align our frontLabel to the frontLED with an X adjustment of 60 units
  lv_obj_align(auLEDLabel, auLED, LV_ALIGN_CENTER, 10, 0); //Align our backLabel to the backLED with an X adjustment of 60 units
  lv_obj_align(opLEDLabel, opLED, LV_ALIGN_CENTER, 10, 0); //Align our fwLabel to the fwLED with an X adjustment of 60 units

  //Set Label Text
  lv_label_set_text(auLEDLabel, "AT");
  lv_label_set_text(opLEDLabel, "OP");
  lv_label_set_text(dbLEDLabel, "DB");

}

void Display::createDiagnosticBars(){

  static lv_color_t needle_colors[] = {LV_COLOR_YELLOW, LV_COLOR_RED, LV_COLOR_CYAN, LV_COLOR_LIME}; //array for needle colours

  gyroGauge = lv_gauge_create(diagnostic_tab, NULL); //create a gauge for the angler position
  gyroLabel = lv_label_create(diagnostic_tab, gyroGauge);
    //lv_gauge_set_style(gyroGauge, &style);
  lv_gauge_set_scale(gyroGauge, 180, 18, 3); //Scale of 360 Degrees, with 18 Dashes and 9 Labels
  lv_gauge_set_range(gyroGauge,  0, 500); //Range of 0-3600, the possible Gyro Values NOTE was -180 180 when it was a gyro
  lv_gauge_set_critical_value(gyroGauge, 400); //Critical value of 2700, meaning the last quarter is full
  lv_gauge_set_needle_count(gyroGauge, 4, needle_colors); //Creates 1 Needle that is Red
  lv_obj_set_size(gyroGauge, 150, 150); //Sets the size to a 180x180 Circle
  lv_obj_align(gyroGauge, NULL, LV_ALIGN_IN_BOTTOM_LEFT, 5, -15); //Align in Left Mid with an X Adjustment of 10
  lv_obj_align(gyroLabel, gyroGauge, LV_ALIGN_CENTER, 55, 140);
    //lv_obj_set_y(gyroGauge, 70);

  visionXBar = lv_bar_create(diagnostic_tab, NULL);
  visionXLabel = lv_label_create(visionXBar, NULL);

  lv_obj_set_size(visionXBar, 110, 30); //sets the size such that this is a horizontal bar
  lv_obj_align(visionXBar, NULL, LV_ALIGN_CENTER, 0, -140); //aligns the second bar to the first with X Adjustment proportional to the size
  lv_bar_set_range(visionXBar, -50, 200); //sets range to be 0 to 680

  lv_obj_set_size(visionXLabel, 70, 30); ///sets label size
  lv_obj_align(visionXLabel, visionXBar, LV_ALIGN_CENTER, -15, 0); //aligns the label to (roughly) the center of the bar
  lv_label_set_text(visionXLabel, "XVal: N/A");

  visionYBar = lv_bar_create(diagnostic_tab, NULL);
  visionYLabel = lv_label_create(visionYBar, NULL);

  lv_obj_set_size(visionYBar, 110, 30); //sets the size such that this is a horizontal bar
  lv_obj_align(visionYBar, visionXBar, LV_ALIGN_CENTER, 0, 45); //aligns the second bar to the first with X Adjustment proportional to the size
  lv_bar_set_range(visionYBar, -50, 200); //sets range to be 0 to 680

  lv_obj_set_size(visionYLabel, 70, 30); ///sets label size
  lv_obj_align(visionYLabel, visionYBar, LV_ALIGN_CENTER, -15, 0); //aligns the label to (roughly) the center of the bar
  lv_label_set_text(visionYLabel, "YVal: N/A");

  visionObjectLabel = lv_label_create(diagnostic_tab, NULL); //creates a label
  lv_obj_align(visionObjectLabel, visionXBar, LV_ALIGN_CENTER, -25, -25); //aligns it to appx. left middle of the page
  lv_label_set_recolor(visionObjectLabel, true); //verifies that we can recolor the text
  lv_label_set_text(visionObjectLabel, "N/A?"); //sets default text

  accelBar = lv_bar_create(diagnostic_tab, NULL);
  accelLabel = lv_label_create(accelBar, NULL);

  lv_obj_set_size(accelBar, 110, 30); //sets the size such that this is a horizontal bar
  lv_obj_align(accelBar, visionYBar, LV_ALIGN_CENTER, 0, 65); //aligns the second bar to the first with X Adjustment proportional to the size
  lv_bar_set_range(accelBar, 1900, 2500); //sets range to be 0 to 680 NOTE CURRENTLY UNKNOWN

  lv_obj_set_size(accelLabel, 70, 30); ///sets label size
  lv_obj_align(accelLabel, accelBar, LV_ALIGN_CENTER, -20, 0); //aligns the label to (roughly) the center of the bar
  lv_label_set_text(accelLabel, "Pitch: N/A");


  accelTitle = lv_label_create(diagnostic_tab, NULL);
  lv_obj_set_size(accelTitle, 70, 30); ///sets label size
  lv_obj_align(accelTitle, accelLabel, LV_ALIGN_CENTER, -35, -25);
  lv_label_set_text(accelTitle, "Accelerometer");

  LV_IMG_DECLARE(Logo_A);
  lv_obj_t * img3 = lv_img_create(diagnostic_tab, NULL);
  lv_img_set_src(img3, &Logo_A);
  //lv_obj_set_size(img3, 110, 110);
  lv_obj_align(img3, gyroGauge, LV_ALIGN_CENTER, 300, 0);

}
void Display::createAutoSelector(void){

  autoSelector = lv_roller_create(disabled_tab, NULL); //create auto selector
  lv_roller_set_options(autoSelector, "None\nUPBlue\nUPRed\nSkills\nVTest\nPRRed"); //sets options to our character array
  lv_obj_set_width(autoSelector, 60); //sets the widtho of our list
  lv_roller_set_visible_row_count(autoSelector, 4);
  lv_roller_set_action(autoSelector, autoSelect_action); //Sets the action to our previously defined function
  lv_obj_align(autoSelector, sys_battery_meter, LV_ALIGN_CENTER, 130, 5); //Align object

}

void Display::createBatteryMeter(void){

  sys_battery_meter = lv_lmeter_create(disabled_tab, NULL); //create a line meter on our disabled mode tab
  bat_meter_label = lv_label_create(sys_battery_meter, NULL); //create a label for the line meter
  symbol_label =  lv_label_create(sys_battery_meter, NULL); //creates a symbol label for the line meter
  lv_lmeter_set_range(sys_battery_meter, 0, 100); //sets the range of the line meter to be 0% to 100%
//  lv_obj_set_size(sys_battery_meter, 80, 80);
  lv_obj_align(sys_battery_meter, NULL, LV_ALIGN_CENTER, 45, 0); //align the line meter to the center of the page with some adjustments
  lv_obj_align(bat_meter_label, sys_battery_meter, LV_ALIGN_CENTER, 8, 0); //align our label to our meter, roughly centered
  lv_obj_align(symbol_label, bat_meter_label, LV_ALIGN_CENTER, -10, 20); //align our second label to the meter, more adjustment because of text size
  lv_lmeter_set_value(sys_battery_meter, 75); //sets default value to 75%
  //lv_label_set_text(bat_meter_label, SYMBOL_BATTERY_2);
  lv_label_set_text(symbol_label, "Battery"); //sets default text
//lv_obj_align(bat_meter_label, sys_battery_meter, LV

  batTemperatureBar = lv_bar_create(disabled_tab, NULL); //create a bar that measures the temperature of the battery
  lv_bar_set_range(batTemperatureBar, 0, 70); //sets range of the bar to be 0C to 70C  70 Degrees is around when battery stops functioning
  lv_obj_align(batTemperatureBar, sys_battery_meter, LV_ALIGN_CENTER, 45, 70); // align to center of System Battery Meter with some minor adjustments
  lv_obj_set_size(batTemperatureBar, 160, 30); //sets the size such that it is a horizontal bar
  lv_bar_set_value(batTemperatureBar, 0); //sets default value of 0

  batTemperatureLabel = lv_label_create(disabled_tab, NULL); //create a label for the previous bar
  lv_obj_align(batTemperatureLabel, batTemperatureBar, LV_ALIGN_CENTER, -30, 0); //align to center of bar with some minor adjustments
  lv_label_set_text(batTemperatureLabel, "N/A"); //throws an unkown as the default - we can tell if its unintialized

  OnOffSwitch = lv_sw_create(disabled_tab, NULL); //declare switches
  lv_obj_t * OnOffLabel = lv_label_create(OnOffSwitch, NULL); //creates a label on the switch
  lv_sw_set_action(OnOffSwitch, fb_switch_action); //sets the action of the switch to be previously defined function
  lv_label_set_text(OnOffLabel, "LOCK"); //sets switch text
  lv_obj_align(OnOffLabel, OnOffSwitch, LV_ALIGN_CENTER, -5, 0);
  lv_obj_set_size(OnOffSwitch, 75, 45); //vertical switch
  lv_obj_align(OnOffSwitch, NULL, LV_ALIGN_IN_BOTTOM_LEFT, 0, -7); //align switch to Top Right with XY change of -25, -25

}

/*If the on switch is on, move the motor a direction multiplied by the forward switch
moves the motor at index i, where i is the element selected from the drop down menu*/
/*
void Display::motorTest(void) //motor test tab that doesn't really work right now :(
{

  SystemMotors[currentTestMotor].move(
    (on ? 67 : 0 ) * (fwd ? 1 : -1)
  );

}
*/
void Display::refresh(void) //refreshes values sent to the screen
{

//gets the largest vision object
  vision_object_s_t biggestObject = visionSensor.get_by_size(0);
//  lv_lmeter_set_value(sys_battery_meter, pros::battery::get_capacity()); //standin
  switch(lv_tabview_get_tab_act(tabs)){ //switch case statement that will only update values for active tab
    case TAB_DISPLAY: //Main Tab for Displaying Match info and Logo

      lv_bar_set_value(batteryBar, pros::battery::get_capacity()); //sets the value of the main bar equal to our batterylevel

      if(button.get_value() == HIGH){lv_led_on(frontLED);} //If the button is pressed turn on the LED
      else{lv_led_off(frontLED);} //Otherwise it is off

      if(LightSensor.get_value() > 2800){lv_led_on(fnlLED);} //if the light sensoris reading > 2000 turn on the LED
      else{lv_led_off(fnlLED);} //otherwise it is off

      if(abs(LiftL.get_position()) < 70 && master.get_digital(E_CONTROLLER_DIGITAL_X)){lv_led_on(lftLED);} //If the temp of the Lift Motor > 55C, turn on LED
      else{lv_led_off(lftLED);} //Otherwise it is off

      if(abs(TrayPot.get_value()) < 1650){lv_led_on(backLED);} //If the angler is in the 'slow zone'
      else{lv_led_off(backLED);} //Otherwise it is off

    case TAB_DIAGNOSTIC:

      //Changes the active LED based on robot Mode
      if(competition::is_disabled()){lv_led_on(dbLED);} //Disabled LED
      else{lv_led_off(dbLED); lv_led_on(opLED);}

      if(competition::is_autonomous()){lv_led_on(auLED);} //Autonomous LED
      else{lv_led_off(auLED); lv_led_on(opLED);}

      //SET AccelerometerVAL

      lv_bar_set_value(accelBar, accelerometer.get_value());
      lv_label_set_text(accelLabel, ("Pitch: " + std::to_string(accelerometer.get_value())).c_str());

      //sets our gauge dials equal to the current draw of each chassis motor and the label equal to the FRONTLEFT chassis current draw
      lv_label_set_text(gyroLabel, ("BFL Current: " + std::to_string((int)BaseFL.get_current_draw())+"mA").c_str()); // convert gyro value to a 360 degree val, then conver string to a constant character and  output to the system
      lv_gauge_set_value(gyroGauge, 0, abs(BaseFL.get_current_draw())); //Sets our dials to be each motor's temperature - these should almost always be the same
      lv_gauge_set_value(gyroGauge, 1, abs(BaseFR.get_current_draw()));
      lv_gauge_set_value(gyroGauge, 2, abs(BaseBL.get_current_draw()));
      lv_gauge_set_value(gyroGauge, 3, abs(BaseBR.get_current_draw()));

      lv_bar_set_value(visionXBar, biggestObject.x_middle_coord);
      lv_label_set_text(visionXLabel, ("XVal: " + std::to_string(biggestObject.x_middle_coord)).c_str());

      lv_bar_set_value(visionYBar, biggestObject.y_middle_coord);
      lv_label_set_text(visionYLabel, ("YVal: " + std::to_string(biggestObject.y_middle_coord)).c_str());

      if(biggestObject.signature == GRN_CUBE){
          lv_label_set_text(visionObjectLabel, ("#06d606 ""Green Object: " + std::to_string(camera.getObjectYVal(biggestObject.signature))+" #" ).c_str()); //display colour and X Value of largest vision object
        }
        else if(biggestObject.signature == PPL_CUBE){
          lv_label_set_text(visionObjectLabel, ("#9705ff ""Purple Object: " + std::to_string(camera.getObjectXVal(biggestObject.signature))+" #" ).c_str()); //display colour and X Value of largest vision object
        }
        else if(biggestObject.signature == ORN_CUBE){
          lv_label_set_text(visionObjectLabel, ("#fc5e03 ""Orange Object:" + std::to_string(camera.getObjectXVal(biggestObject.signature))+" #" ).c_str()); //display colour and X Value of largest vision object
        }
        else{
          lv_label_set_text(visionObjectLabel, ("No Object!"));
        }

    case TAB_INFO: //Information Tab with battery levels and other Information

        //sets labels of sensor values to equal sensor outputs
        lv_label_set_text(rightUltLabel, ("RU:" + std::to_string(rightUlt.get_value())).c_str());
        lv_label_set_text(leftUltLabel, ("LU:" + std::to_string(leftUlt.get_value())).c_str());
        lv_label_set_text(lightSensorLabel, ("LS:" + std::to_string(LightSensor.get_value())).c_str());


        //gets Lift and Tray position values
        int baseOutput = abs(TrayPot.get_value_calibrated());
        int liftOutput = abs(LiftL.get_position());

        //changes the value of our bars
        lv_bar_set_value(motorBar1, baseOutput);
        lv_bar_set_value(motorBar2, liftOutput);
        lv_bar_set_value(motorBar3, rollerSpeed);

        //sets the bar labels to be equal to the output values
        lv_label_set_text(motorLabel2, (std::to_string(abs(liftOutput)).c_str()));
        lv_label_set_text(motorLabel1, (std::to_string(baseOutput)).c_str());
        lv_label_set_text(motorLabel3, (std::to_string(rollerSpeed)).c_str());

        //gets the battery level
        int level = pros::battery::get_capacity();

        //sets our meter and the meter label equal to the battery level
        lv_lmeter_set_value(sys_battery_meter, level);
        lv_label_set_text(bat_meter_label, (std::to_string(level)+"%").c_str()); //convert level(int) to string to a const char

        lv_bar_set_value(batTemperatureBar, pros::battery::get_temperature()); //sets the value of our bar to be the battery temperature
        lv_label_set_text(batTemperatureLabel, ("BatTMP:" + std::to_string((int)pros::battery::get_temperature()) + "°C").c_str()); //casts an int to the battery temperature, then converts it to a string then a const char
  }

}

void Display::setActiveTab(int tab){ //changes the active tab to be a given index
  lv_tabview_set_tab_act(tabs, tab, LV_ANIM_NONE); //changes active tab
}

void Display::createScreen(void) { //calls all of our functions to make the screen

    th = lv_theme_alien_init(120, NULL); //Sets the theme, 60 For TTYellow
    //lv_theme_set_current(th);
    lv_tabview_set_sliding(tabs, false); //do not slide the tabs to save brain powah
    lv_tabview_set_anim_time(tabs, 0); //Disable animations to save the brain because otherwise he cries
    //Call all of our functions
    createTitle(); //create our titles and labels - the ones that vary
    create1010Image(); //creates our image
    createBatteryMeter(); //creates our battery line meter, bar and labels
    createOpLEDs(); //creates our OpControl LEDs
    createDiagnosticBars(); //creates the bars on the diagnostic tab
    createGauge(); //creates our gauge and our vertical bars
    createAutoSelector(); //creates the auto selector
    createStateLEDs(); //creates out state LEDs on the diagnostic tab

}
